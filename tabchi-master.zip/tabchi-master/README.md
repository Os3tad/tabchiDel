# [Tabchi | v.1](https://telegram.me/Os3tad_team)

تبچی ساز استاد 
بدون دلیت شدن 


* * *

### دستورات


| [#!/]help | راهنما  |


* * *

# نصب

```sh
git clone https://github.com/Os3tad/tabchiDel
cd tabchi
chmod +x bot
./bot install
# and send [y] to finish install
```
* * *
## ساخت ربات
```
./bot create
./bot 1
وارد کردن ایدی عددی سودو#
وارد کردن شماره ربات#
```
## ساخت ربات های بیش تر

```sh
cd tabchi
./bot create
./bot number of bot >> شماره رباتی که به شما میدهد
وارد کردن ایدی عددی سودو#
وارد کردن شماره ربات#
```
* * *
## اتولاچ
```sh
cd tabchi
./bot autolaunch
تمام ربات ها راه اندازی میشوند بدون خاموشی#
```
***


### Developers
[mohammadrezajiji](https://telegram.me/Os3tad)
### channel
[TitanTeam](https://telegram.me/Os3tad_team)
